# Resource Guide d’Implémentation FHIR – Pré-admission Hospitalière en Ligne



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "hl7.fhir.fr.preadmission",
  "language" : "en",
  "url" : "https://hl7.fr/ig/fhir/preadmission/ImplementationGuide/hl7.fhir.fr.preadmission",
  "version" : "1.0.0-ballot",
  "name" : "PREADMISSIONFR",
  "title" : "Guide d’Implémentation FHIR – Pré-admission Hospitalière en Ligne",
  "status" : "active",
  "date" : "2026-10-21T10:07:38+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org/"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "packageId" : "hl7.fhir.fr.preadmission",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.4.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "hl7_fhir_fr_core",
    "uri" : "https://hl7.fr/ig/fhir/core/ImplementationGuide/hl7.fhir.fr.core",
    "packageId" : "hl7.fhir.fr.core",
    "version" : "2.2.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2024+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ballot"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid-template"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://hl7.fr/ig/fhir/preadmission/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CapabilityStatement"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CapabilityStatement-PreadmissionCapabilityStatement.html"
      }],
      "reference" : {
        "reference" : "CapabilityStatement/PreadmissionCapabilityStatement"
      },
      "name" : "Capacités serveur FHIR pour l'IG Preadmission",
      "description" : "Décrit les capacités d’un serveur FHIR conforme à l’IG de préadmission hospitalière en France.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-consentement-dmp-alimentation.html"
      }],
      "reference" : {
        "reference" : "Consent/consentement-dmp-alimentation"
      },
      "name" : "Consentement alimentation DMP",
      "description" : "Consentement pour l’alimentation du DMP, non recueilli (provision.type vide).",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-consent-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-consentement-dmp-consultation.html"
      }],
      "reference" : {
        "reference" : "Consent/consentement-dmp-consultation"
      },
      "name" : "Consentement consultation DMP",
      "description" : "Consentement pour la consultation du DMP, recueilli (provision.type permit).",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-consent-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-consentement-multi.html"
      }],
      "reference" : {
        "reference" : "Consent/consentement-multi"
      },
      "name" : "Consentement global incluant consultation DMP, alimentation DMP et partage d'information",
      "description" : "Exemple d'une ressource Consent combinant plusieurs provisions pour la consultation du DMP, l'alimentation du DMP et le partage d'informations avec un logiciel tiers pour des communications par SMS ou e-mail.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-consent-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-encounter-agent-instructions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/encounter-agent-instructions"
      },
      "name" : "Consignes de l'agent administratif",
      "description" : "Consignes à destination du patient, fournies par l'agent administratif",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-irm-externe.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-irm-externe"
      },
      "name" : "Consultation IRM externe",
      "description" : "Initialisation de la préadmission par la GAP, suite à la réception dun rendez-vous - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-encounter-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-irm-refused.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-irm-refused"
      },
      "name" : "Consultation IRM refusée",
      "description" : "Consultation IRM refusée par l'agent du bureau des entrées - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-encounter-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Coverage"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Coverage-coverage-amc.html"
      }],
      "reference" : {
        "reference" : "Coverage/coverage-amc"
      },
      "name" : "Couverture sociale AMC",
      "description" : "Couverture sociale AMC - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-coverage-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Coverage"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Coverage-coverage-amo-enfant.html"
      }],
      "reference" : {
        "reference" : "Coverage/coverage-amo-enfant"
      },
      "name" : "Couverture sociale AMO",
      "description" : "Couverture sociale AMO - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-coverage-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Coverage"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Coverage-coverage-amo.html"
      }],
      "reference" : {
        "reference" : "Coverage/coverage-amo"
      },
      "name" : "Couverture sociale AMO",
      "description" : "Couverture sociale AMO - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-coverage-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "DocumentReference-documentreference-cni-recto.html"
      }],
      "reference" : {
        "reference" : "DocumentReference/documentreference-cni-recto"
      },
      "name" : "Document de préadmission - CNI recto",
      "description" : "Scan du recto de la carte d'identité du patient - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-documentreference-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-document-type-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/document-type-cs"
      },
      "name" : "document-type-cs",
      "description" : "Types de documents additionnels pour la préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-document-type-ins-cs.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/document-type-ins-cs"
      },
      "name" : "document-type-ins-cs",
      "description" : "Types de documents additionnels pour qualifer une identité",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Encounter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Encounter-encounter-irm-complete.html"
      }],
      "reference" : {
        "reference" : "Encounter/encounter-irm-complete"
      },
      "name" : "Encounter IRM complété par le patient",
      "description" : "Exemple d'une ressource Encounter complété par le patient sur le portail de préadmission pour une préadmission liée à un rendez-vous IRM externe, avec statut READY, consentements DMP, et réponse au questionnaire sur la chambre particulière.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-encounter-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "SearchParameter"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "SearchParameter-encounter-preadmission-status.html"
      }],
      "reference" : {
        "reference" : "SearchParameter/encounter-preadmission-status"
      },
      "name" : "Encounter Preadmission Status SearchParameter",
      "description" : "Recherche des encounters par statut de pré-admission (extension PreadmissionStatutFr).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-coverage-amc-extended.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-coverage-amc-extended"
      },
      "name" : "Extension AMC Étendue ROC",
      "description" : "Extension pour les informations AMC étendues issues de l'attestation harmonisée / DataMatrix AMC",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-statut-preadmission-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/statut-preadmission-fr"
      },
      "name" : "Extension Statut Pré-admission",
      "description" : "Statut de pré-admission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-preadmission-appointment-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/preadmission-appointment-fr"
      },
      "name" : "Fr Preadmission Appointment Profile",
      "description" : "Profil Appointment pour un rendez-vous de préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-preadmission-consent-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/preadmission-consent-fr"
      },
      "name" : "Fr Preadmission Consent Profile",
      "description" : "Profil Consent pour les consentements lors de la préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-preadmission-coverage-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/preadmission-coverage-fr"
      },
      "name" : "Fr Preadmission Coverage Profile",
      "description" : "Profil Coverage pour les couvertures sociales lors de la préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-preadmission-documentreference-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/preadmission-documentreference-fr"
      },
      "name" : "Fr Preadmission DocumentReference Profile",
      "description" : "Profil DocumentReference pour un document administratif de préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-preadmission-encounter-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/preadmission-encounter-fr"
      },
      "name" : "Fr Preadmission Encounter Profile",
      "description" : "Profil Encounter pour une préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-preadmission-questionnaireresponse-fr.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/preadmission-questionnaireresponse-fr"
      },
      "name" : "Fr Preadmission QuestionnaireResponse Profile",
      "description" : "Profil QuestionnaireResponse pour les réponses aux questionnaires de préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patient-001.html"
      }],
      "reference" : {
        "reference" : "Patient/patient-001"
      },
      "name" : "Patient de préadmission",
      "description" : "Patient de préadmission - référencé dans les autres exemples.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Patient-patient-parent.html"
      }],
      "reference" : {
        "reference" : "Patient/patient-parent"
      },
      "name" : "Patient de préadmission",
      "description" : "Patient de préadmission - référencé dans les autres exemples.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Practitioner"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Practitioner-practitioner-irm.html"
      }],
      "reference" : {
        "reference" : "Practitioner/practitioner-irm"
      },
      "name" : "Praticien IRM",
      "description" : "Médecin IRM, référencé dans les autres ressources - préadmission.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-preadmission-consent-category-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/preadmission-consent-category-vs"
      },
      "name" : "preadmission-consent-category-vs",
      "description" : "ValueSet pour les catégories de consentement. Tous les codes sont standards et existants.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-preadmission-consent-code-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/preadmission-consent-code-vs"
      },
      "name" : "preadmission-consent-code-vs",
      "description" : "Code HL7 représentant les types d'action concernées par le consentement. Tous les codes sont standards et existants.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-preadmission-consent-purpose-reason-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/preadmission-consent-purpose-reason-vs"
      },
      "name" : "preadmission-consent-purpose-reason-vs",
      "description" : "Raisons justifiant l’utilisation des données personnelles (HL7 v3 ActReason).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-preadmission-document-type-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/preadmission-document-type-vs"
      },
      "name" : "preadmission-document-type-vs",
      "description" : "Liste des types de documents autorisés pour la préadmission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-preadmission-status-code-system.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/preadmission-status-code-system"
      },
      "name" : "preadmission-status-code-system",
      "description" : "Statut de pré-admission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-preadmission-statuts-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/preadmission-statuts-vs"
      },
      "name" : "preadmission-status-vs",
      "description" : "Statuts valides qu'une préadmission peut prendre.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Appointment"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Appointment-appt-irm-001.html"
      }],
      "reference" : {
        "reference" : "Appointment/appt-irm-001"
      },
      "name" : "Prise de rendez-vous IRM cérébrale",
      "description" : "Rendez-vous pour une IRM cérébrale - préadmission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-appointment-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-qr-irm-001.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/qr-irm-001"
      },
      "name" : "Questionnaire préadmission IRM",
      "description" : "Questionnaire posé lors de la prise de rendez-vous pour une IRM.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-questionnaireresponse-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-questionnaire-chb-part.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/questionnaire-chb-part"
      },
      "name" : "Questionnaire préadmission IRM",
      "description" : "Questionnaire posé par le portail de pré-admission.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Consent-consentement-refus-rgpd.html"
      }],
      "reference" : {
        "reference" : "Consent/consentement-refus-rgpd"
      },
      "name" : "Refus du consentement RGPD",
      "description" : "Exemple d'une ressource Consent en FHIR pour un refus explicite du traitement des données personnelles dans le cadre du RGPD.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-consent-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-encounter-patient-comment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/encounter-patient-comment"
      },
      "name" : "Remarque du patient",
      "description" : "Remarque libre saisie par le patient à destination de l’agent administratif",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-questionnaire-irm.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/questionnaire-irm"
      },
      "name" : "Reponse Questionnaire préadmission IRM",
      "description" : "Réponses au questionnaire posé lors de la prise de rendez-vous pour une IRM.",
      "exampleBoolean" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "QuestionnaireResponse"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "QuestionnaireResponse-qr-chb-part.html"
      }],
      "reference" : {
        "reference" : "QuestionnaireResponse/qr-chb-part"
      },
      "name" : "Réponse questionnaire chambre particulière",
      "description" : "Réponse du patient au questionnaire posé par le portail de pré-admission.",
      "exampleCanonical" : "https://hl7.fr/ig/fhir/preadmission/StructureDefinition/preadmission-questionnaireresponse-fr"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-type-couverture-sociale-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/type-couverture-sociale-vs"
      },
      "name" : "type-couverture-sociale-vs",
      "description" : "Restreint les types de couverture à PUBLICPOL (AMO) et EHCPOL (AMC)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-type-venue-encounter-vs.html"
      }],
      "reference" : {
        "reference" : "ValueSet/type-venue-encounter-vs"
      },
      "name" : "type-venue-encounter-vs",
      "description" : "Les différents types d'admission (hospitalisation, consultation, etc.)",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Accueil",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "processus.html"
        }],
        "nameUrl" : "processus.html",
        "title" : "Processus fonctionnelle de la préadmission",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "processus-ressource-fhir.html"
        }],
        "nameUrl" : "processus-ressource-fhir.html",
        "title" : "Processus centré sur les ressources",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "flux.html"
        }],
        "nameUrl" : "flux.html",
        "title" : "Diagrammes des flux",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "sequence.html"
        }],
        "nameUrl" : "sequence.html",
        "title" : "Diagramme de séquence du processus",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Téléchargement du guide",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "history.html"
        }],
        "nameUrl" : "history.html",
        "title" : "Historique des versions",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
