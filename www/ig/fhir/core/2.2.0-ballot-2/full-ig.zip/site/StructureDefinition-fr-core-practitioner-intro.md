### Usage

French profile of the Practitioner resource. This profile specifies the types of identifiers for practitioners in France.
Profil de la ressource Practitionner pour la France. Ce profil contraint les types d'identifiants du professionnel de santé en France.

Ce profil représente le professionel ainsi que son exercice professionel.

Pour une même personne au sens civil, il peut y avoir plusieurs ressources Practitionner pour chacun de ces exercice professionnel (ex : un médecin qui est également pharmacien aura deux ressources Practitioner). La reconciliation peut se faire au niveau de l'identifier (même numéro RPPS) ou bien en utilisant la ressource Person pour décrire l'identité civile du practicien.
