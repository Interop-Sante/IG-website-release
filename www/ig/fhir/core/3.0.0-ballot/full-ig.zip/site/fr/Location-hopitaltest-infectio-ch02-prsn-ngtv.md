# hopitaltest-infectio-ch02-prsn-ngtv - Guide d'implémentation FR Core v3.0.0-ballot

## Exemple Location: hopitaltest-infectio-ch02-prsn-ngtv

-------

**French**

-------

Profil: [FR Core Location Profile](StructureDefinition-fr-core-location.md)

Chambre 02 - Pression négative (Chambre)

-------

| | |
| :--- | :--- |
| Status: | Active |
| Type: | Chambre |
| Managed By: | [CHRU CENTRE VILLE (Etablissement Géographique) (FINESS d'entité géographique: 350009999 (use: official))](Organization-hopitaltest-eg-4-members.md) |
| [FR Core Location Extension - Type de chambre](StructureDefinition-fr-core-location-type-chambre.md) | [FR Core CodeSystem Type Chambre: PRSN_NGTV](CodeSystem-fr-core-cs-location-type-chambre.md#fr-core-cs-location-type-chambre-PRSN_NGTV)(Pression négative) |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "hopitaltest-infectio-ch02-prsn-ngtv",
  "meta" : {
    "profile" : ["https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-location"]
  },
  "extension" : [{
    "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-location-type-chambre",
    "valueCoding" : {
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-location-type-chambre",
      "code" : "PRSN_NGTV",
      "display" : "Pression négative"
    }
  }],
  "status" : "active",
  "name" : "Chambre 02 - Pression négative",
  "type" : [{
    "coding" : [{
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-location-type",
      "code" : "CHAMB",
      "display" : "Chambre"
    }],
    "text" : "Chambre"
  }],
  "managingOrganization" : {
    "reference" : "Organization/hopitaltest-eg-4-members"
  }
}

```
