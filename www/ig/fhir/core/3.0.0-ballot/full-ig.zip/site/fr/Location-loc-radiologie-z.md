# FRCoreLocationExample - Guide d'implémentation FR Core v3.0.0-ballot

## Exemple Location: FRCoreLocationExample

-------

**French**

-------

Centre de radiologie Hôpital Z (urn:oid:1.2.250.1.1.1.2#HOSPZ-RADIO (use: official))

-------

| | | | |
| :--- | :--- | :--- | :--- |
| Status: | Active | Mode: | Instance |
| Form: | Bâtiment | | |
| Description: | Imagerie médicale, radiographies, scanners, IRM | | |
| Address: | 10 rue de la Santé Paris 75014 FRA | | |
| Coordonnées | [radiologie@hosp-z.fr](mailto:radiologie@hosp-z.fr) | | |
| Position: | 48.8333, 2.3333 (altitude 35) | | |
| Managed By: | [HOPITAL INTERCOMMUNAL DE LA PRESQU'ILE G (Entité légale, Secteur non défini) (Identification nationale de structure définie par l’ANS dans le CI_SIS: 2264403106 (use: official))](Organization-FRCoreOrganizationExample.md) | | |



## Resource Content

```json
{
  "resourceType" : "Location",
  "id" : "loc-radiologie-z",
  "identifier" : [{
    "use" : "official",
    "system" : "urn:oid:1.2.250.1.1.1.2",
    "value" : "HOSPZ-RADIO"
  }],
  "status" : "active",
  "name" : "Centre de radiologie Hôpital Z",
  "description" : "Imagerie médicale, radiographies, scanners, IRM",
  "mode" : "instance",
  "telecom" : [{
    "system" : "email",
    "value" : "radiologie@hosp-z.fr"
  }],
  "address" : {
    "line" : ["10 rue de la Santé"],
    "city" : "Paris",
    "district" : "14e arrondissement",
    "postalCode" : "75014",
    "country" : "FRA"
  },
  "physicalType" : {
    "coding" : [{
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-location-physical-type",
      "code" : "BTMNT",
      "display" : "Bâtiment"
    }]
  },
  "position" : {
    "longitude" : 2.3333,
    "latitude" : 48.8333,
    "altitude" : 35
  },
  "managingOrganization" : {
    "reference" : "Organization/FRCoreOrganizationExample"
  }
}

```
