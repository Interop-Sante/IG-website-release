# FR Core BodyStructure Profile - Guide d'implémentation FR Core v3.0.0-ballot

## Resource Profile: FR Core BodyStructure Profile 

**Usages:**

* Refer to this Profile: [FR Core Procedure Profile](StructureDefinition-fr-core-procedure.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.fr.core|current/StructureDefinition/StructureDefinition-fr-core-body-structure.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-fr-core-body-structure.csv), [Excel](../StructureDefinition-fr-core-body-structure.xlsx), [Schematron](../StructureDefinition-fr-core-body-structure.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "fr-core-body-structure",
  "url" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-body-structure",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreBodyStructureProfile",
  "title" : "FR Core BodyStructure Profile",
  "status" : "active",
  "date" : "2026-11-09T10:42:35+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "FRCoreBodyStructureProfile est un profil FRCore utilisé pour préciser les modificateurs topographiques associés à une localisation anatomique.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "openehr",
    "uri" : "http://openehr.org",
    "name" : "Open EHR Archetype Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "BodyStructure",
  "baseDefinition" : "http://hl7.eu/fhir/base/StructureDefinition/bodyStructure-eu-core|2.0.0",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "BodyStructure",
      "path" : "BodyStructure"
    },
    {
      "id" : "BodyStructure.meta.profile",
      "path" : "BodyStructure.meta.profile",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "$this"
        }],
        "description" : "Slice based on the canonical url value",
        "rules" : "open"
      }
    },
    {
      "id" : "BodyStructure.meta.profile:fr-canonical",
      "path" : "BodyStructure.meta.profile",
      "sliceName" : "fr-canonical",
      "min" : 0,
      "max" : "1",
      "patternCanonical" : "https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-body-structure|3.0.0-ballot"
    },
    {
      "id" : "BodyStructure.extension:includedStructure",
      "path" : "BodyStructure.extension",
      "sliceName" : "includedStructure"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:structure",
      "path" : "BodyStructure.extension.extension",
      "sliceName" : "structure",
      "short" : "Localisation anatomique ou voie d'abord"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:structure.value[x]",
      "path" : "BodyStructure.extension.extension.value[x]",
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-body-structure-location|3.0.0-ballot"
      }
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:laterality",
      "path" : "BodyStructure.extension.extension",
      "sliceName" : "laterality"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:laterality.value[x]",
      "path" : "BodyStructure.extension.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-lateralite-cisis|20260928134055"
      }
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:bodyLandmarkOrientation",
      "path" : "BodyStructure.extension.extension",
      "sliceName" : "bodyLandmarkOrientation"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:bodyLandmarkOrientation.extension:distanceFromLandmark",
      "path" : "BodyStructure.extension.extension.extension",
      "sliceName" : "distanceFromLandmark"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:bodyLandmarkOrientation.extension:distanceFromLandmark.extension:device",
      "path" : "BodyStructure.extension.extension.extension.extension",
      "sliceName" : "device"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:bodyLandmarkOrientation.extension:distanceFromLandmark.extension:device.extension",
      "path" : "BodyStructure.extension.extension.extension.extension.extension",
      "min" : 1
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:qualifier",
      "path" : "BodyStructure.extension.extension",
      "sliceName" : "qualifier",
      "short" : "Modificateurs topographiques"
    },
    {
      "id" : "BodyStructure.extension:includedStructure.extension:qualifier.value[x]",
      "path" : "BodyStructure.extension.extension.value[x]",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://smt.esante.gouv.fr/fhir/ValueSet/jdv-modificateur-topographique-cisis|20260928134049"
      }
    }]
  }
}

```
