# FR Core ValueSet Identity Status Comment - Guide d'implémentation FR Core v3.0.0-ballot

## ValueSet: FR Core ValueSet Identity Status Comment 

 **References** 

* [FR Core Patient Identity Reliability Extension](StructureDefinition-fr-core-identity-reliability.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-core-vs-identity-status-comment",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-identity-status-comment",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreValueSetIdentityStatusComment",
  "title" : "FR Core ValueSet Identity Status Comment",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-09T10:42:35+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "ValueSet permettant de commenter / de rajouter des attributs sur la fiabilité d'une identité. Ces codes sont destinés à être utilisés dans la sous-extension `comment` de l'extension `fr-core-identity-reliability`.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-identity-status-comment",
      "version" : "3.0.0-ballot"
    }]
  }
}

```
