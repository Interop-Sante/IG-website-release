# FR Core ValueSet Codes Tarifs - nomenclature TNJP - Guide d'implémentation FR Core v3.0.0-ballot

## ValueSet: FR Core ValueSet Codes Tarifs - nomenclature TNJP 

 **References** 

* [FR Core Organization Extension - Tarif Soin](StructureDefinition-fr-core-organization-tarif.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-core-vs-organization-code-tarif-tnjp",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-organization-code-tarif-tnjp",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreValueSetOrganizationCodeTarifTNJP",
  "title" : "FR Core ValueSet Codes Tarifs - nomenclature TNJP",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-09T10:42:35+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Valeurs permettant de coder les codes TNJP (Tarification nationale journalière des prestations).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://hl7.fr/ig/fhir/core/CodeSystem/fr-core-cs-code-tarif-tnjp",
      "version" : "3.0.0-ballot"
    }]
  }
}

```
