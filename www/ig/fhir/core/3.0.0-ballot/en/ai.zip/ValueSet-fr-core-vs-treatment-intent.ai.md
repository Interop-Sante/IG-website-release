# FR Core ValueSet Treatment Intent - Guide d'implémentation FR Core v3.0.0-ballot

## ValueSet: FR Core ValueSet Treatment Intent 

 **References** 

* [FR Core MedicationRequest Treatment Intent Extension](StructureDefinition-fr-core-treatment-intent.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "fr-core-vs-treatment-intent",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset|4.0.1"]
  },
  "language" : "fr-FR",
  "url" : "https://hl7.fr/ig/fhir/core/ValueSet/fr-core-vs-treatment-intent",
  "version" : "3.0.0-ballot",
  "name" : "FRCoreValueSetTreatmentIntent",
  "title" : "FR Core ValueSet Treatment Intent",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-11-09T10:42:35+00:00",
  "publisher" : "Interop'Santé",
  "contact" : [{
    "name" : "Interop'Santé",
    "telecom" : [{
      "system" : "url",
      "value" : "http://interopsante.org"
    }]
  },
  {
    "name" : "InteropSanté",
    "telecom" : [{
      "system" : "email",
      "value" : "fhir@interopsante.org",
      "use" : "work"
    }]
  }],
  "description" : "Jeu de valeurs SNOMED CT pour l'intention globale du traitement (MedicationRequest).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "filter" : [{
        "property" : "concept",
        "op" : "is-a",
        "value" : "363675004"
      }]
    }]
  }
}

```
